package com.example.labortatorio4GrupalUno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Labortatorio4GrupalUnoApplicationTests {

	@Test
	void contextLoads() {
	}

}
